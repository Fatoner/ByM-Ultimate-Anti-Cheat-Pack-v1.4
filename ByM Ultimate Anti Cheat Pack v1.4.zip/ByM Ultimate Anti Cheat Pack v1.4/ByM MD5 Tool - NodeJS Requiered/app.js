const folder = 'PATH TO THE THIS FOLDER HERE'; // Example: 'D:\\ByM MD5 Tool\\';

const fs = require( 'fs' );
const md5File = require( 'md5-file' );

fs.readdirSync( folder ).forEach(file => {
        if( file == "app.js" || file == "package.json" || file == "node_modules" || file == "readme.txt" )
                return;

	md5File( file, ( error, hash ) => {
  		console.log( `${file} -- MD5: ${hash}` );
	} );
})