NodeJS Requiered (Download and install if you do not have it: https://nodejs.org/en/)

Usage:
Edit app.js and replace folder variable content with the path to this folder
Example: Example: const folder = 'C:\Users\Bob\ByM Ultimate Anti Cheat\ByM MD5 Tool - NodeJS Requiered';

Paste files which you want to get their MD5 hash in this folder.
Click on white void in folder, hold CTRL + SHIFT and click right click. (Do not select files).
Select Start Command Windown or Power Shell (Depends on you OS).

Type: node app.js
Enjoy.
